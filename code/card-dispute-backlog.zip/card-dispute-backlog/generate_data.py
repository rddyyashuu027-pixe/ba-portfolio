"""Generate a synthetic card dispute case dataset (12 months).

Nothing here is real bank data. Timelines follow the public rules:
  * Credit cards, Regulation Z: resolve within two billing cycles (max 90 days).
  * Debit cards, Regulation E: provisional credit within 10 business days,
    resolve within 45 days (90 for new accounts / POS / foreign).
Run:  python generate_data.py
"""
import csv
import math
import random
from datetime import date, timedelta
from pathlib import Path

random.seed(7)
OUT = Path(__file__).parent / "data"
OUT.mkdir(exist_ok=True)

REASONS = {  # reason: (share, base median days, needs merchant docs)
    "Fraud / unauthorized": (0.44, 6.0, False),
    "Merchandise not received": (0.16, 11.0, True),
    "Not as described": (0.13, 14.0, True),
    "Credit not processed": (0.11, 8.0, True),
    "Duplicate charge": (0.10, 4.0, False),
    "Incorrect amount": (0.06, 7.0, True),
}
CHANNELS = {"Phone": (0.45, 0.58), "Online banking": (0.34, 0.70), "Mobile app": (0.21, 0.78)}
QUEUES = {"Fraud / unauthorized": "Fraud Claims", "Duplicate charge": "Billing Errors",
          "Incorrect amount": "Billing Errors", "Credit not processed": "Merchant Disputes",
          "Merchandise not received": "Merchant Disputes", "Not as described": "Merchant Disputes"}


def daily_volume(d):
    weekday = [1.25, 1.15, 1.05, 1.0, 0.95, 0.55, 0.45][d.weekday()]
    season = 1 + 0.18 * math.cos(2 * math.pi * (d.timetuple().tm_yday - 15) / 365)  # Jan peak
    trend = 1 + 0.10 * (d - date(2024, 7, 1)).days / 365
    return 165 * weekday * season * trend


def main():
    rows, cid = [], 0
    d = date(2024, 7, 1)
    while d <= date(2025, 6, 30):
        for _ in range(int(random.gauss(daily_volume(d), daily_volume(d) ** 0.5))):
            cid += 1
            reason = random.choices(list(REASONS), [v[0] for v in REASONS.values()])[0]
            _, base_days, needs_docs = REASONS[reason]
            channel = random.choices(list(CHANNELS), [v[0] for v in CHANNELS.values()])[0]
            card = "Credit" if random.random() < 0.68 else "Debit"
            amount = round(min(9000, random.lognormvariate(4.6, 1.05)), 2)
            docs_complete = (not needs_docs) or random.random() < CHANNELS[channel][1]
            misrouted = random.random() < (0.07 if reason in ("Fraud / unauthorized", "Duplicate charge") else 0.17)

            evidence_requests = 0 if docs_complete else random.choices([1, 2, 3], [60, 30, 10])[0]
            days = random.lognormvariate(math.log(base_days), 0.45)
            days += evidence_requests * random.uniform(1.6, 2.8)   # wait for customer/merchant docs
            days += 2.3 * misrouted + random.uniform(0, 1.0) * misrouted
            days += 0.35 * (amount > 500)                           # second-level review
            days = round(days, 1)

            reg_limit = 90 if card == "Credit" else 45
            reopen_p = 0.045 + 0.075 * (evidence_requests > 0) + 0.03 * misrouted
            rows.append([
                f"D{cid:06d}", d.isoformat(), card, reason, channel, QUEUES[reason],
                amount, int(docs_complete), evidence_requests, int(misrouted), days,
                (d + timedelta(days=days)).isoformat(), reg_limit,
                int(random.random() < reopen_p),
                random.choices(["Customer favor", "Merchant favor", "Withdrawn"], [64, 27, 9])[0],
            ])
        d += timedelta(days=1)

    with open(OUT / "disputes.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["case_id", "opened_date", "card_type", "reason", "intake_channel", "queue",
                    "amount", "docs_complete_at_intake", "evidence_requests", "misrouted",
                    "resolution_days", "resolved_date", "reg_limit_days", "reopened", "outcome"])
        w.writerows(rows)
    print(f"wrote {len(rows):,} dispute cases -> {OUT}")


if __name__ == "__main__":
    main()
