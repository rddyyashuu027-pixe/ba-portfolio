"""Card dispute backlog analysis: SQL diagnostics, delay-driver model, staffing forecast, scenario.

    python generate_data.py && python analyze.py
"""
import json
import sqlite3
from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = Path(__file__).parent
RES = ROOT / "results"
RES.mkdir(exist_ok=True)

# Scenario assumptions, agreed with operations in a real engagement.
CHECKLIST_FIX = {"Phone": 0.50, "Online banking": 0.65, "Mobile app": 0.65}  # share of incomplete claims an intake checklist fixes (agent script / required upload)
ROUTING_RULE_FIX = 0.70        # share of misroutes a reason-code routing table prevents
HANDLE_HOURS_PER_CASE = 1.6    # investigator touch time, hours
PRODUCTIVE_HOURS_PER_FTE_WEEK = 30


def sql_results(df):
    con = sqlite3.connect(":memory:")
    df.to_sql("disputes", con, index=False)
    out = {}
    for f in sorted((ROOT / "sql").glob("*.sql")):
        out[f.stem] = pd.read_sql(f.read_text(), con).to_dict("records")
        (RES / f"{f.stem}.md").write_text(pd.DataFrame(out[f.stem]).to_markdown(index=False) + "\n")
        print(f"\n## {f.stem}\n" + pd.DataFrame(out[f.stem]).to_markdown(index=False))
    return out


def delay_model(df):
    """OLS: how many days does each process failure add, holding reason and amount constant?"""
    X = pd.get_dummies(df["reason"], drop_first=True, dtype=float)
    X["evidence_requests"] = df["evidence_requests"]
    X["misrouted"] = df["misrouted"]
    X["amount_over_500"] = (df["amount"] > 500).astype(float)
    X.insert(0, "intercept", 1.0)
    beta, *_ = np.linalg.lstsq(X.values, df["resolution_days"].values, rcond=None)
    coef = dict(zip(X.columns, beta.round(2)))
    print("\n## delay model (days added)\n", {k: coef[k] for k in ("evidence_requests", "misrouted", "amount_over_500")})
    return coef


def forecast(df):
    """Weekly intake forecast, backtested on the last 12 weeks. Accuracy = 100 - MAPE."""
    wk = df.groupby(pd.to_datetime(df["opened_date"]).dt.to_period("W").dt.start_time).size()
    wk = wk.iloc[1:-1]  # drop partial weeks
    y = wk.values.astype(float)
    test = 12
    preds = {"Naive (last week)": [], "4-week average": [], "Holt trend smoothing": []}
    for t in range(len(y) - test, len(y)):
        hist = y[:t]
        preds["Naive (last week)"].append(hist[-1])
        preds["4-week average"].append(hist[-4:].mean())
        level, trend, a, b = hist[0], 0.0, 0.5, 0.15
        for v in hist[1:]:
            prev = level
            level = a * v + (1 - a) * (level + trend)
            trend = b * (level - prev) + (1 - b) * trend
        preds["Holt trend smoothing"].append(level + trend)
    actual = y[-test:]
    acc = {k: round(100 - 100 * np.mean(np.abs(np.array(p) - actual) / actual), 1) for k, p in preds.items()}
    best = max(acc, key=acc.get)
    print("\n## forecast accuracy (100 - MAPE), last 12 weeks\n", acc)
    next_week = preds[best][-1]
    fte = next_week * HANDLE_HOURS_PER_CASE / PRODUCTIVE_HOURS_PER_FTE_WEEK
    return {"accuracy": acc, "best": best, "weeks": [str(d.date()) for d in wk.index],
            "actual": y.tolist(), "backtest": {k: [round(v) for v in p] for k, p in preds.items()},
            "investigator_fte_needed": round(fte, 1)}


def scenario(df, coef):
    rng = np.random.default_rng(1)
    s = df.copy()
    gap = s["evidence_requests"] > 0
    fix_docs = gap & (rng.random(len(s)) < s["intake_channel"].map(CHECKLIST_FIX))
    fix_route = (s["misrouted"] == 1) & (rng.random(len(s)) < ROUTING_RULE_FIX)
    s.loc[fix_docs, "resolution_days"] -= coef["evidence_requests"] * s.loc[fix_docs, "evidence_requests"]
    s.loc[fix_route, "resolution_days"] -= coef["misrouted"]
    s["resolution_days"] = s["resolution_days"].clip(lower=1)
    # reopen risk: fixed cases take the reopen rate of comparable clean cases
    clean_rate = df.loc[(df.evidence_requests == 0) & (df.misrouted == 0), "reopened"].mean()
    expected_reopen = s["reopened"].astype(float)
    expected_reopen[fix_docs | fix_route] = clean_rate
    out = {
        "median_days_today": float(df["resolution_days"].median()),
        "median_days_after": float(round(s["resolution_days"].median(), 1)),
        "avg_days_today": round(df["resolution_days"].mean(), 1),
        "avg_days_after": round(s["resolution_days"].mean(), 1),
        "pct_over_10d_today": round(100 * (df["resolution_days"] > 10).mean(), 1),
        "pct_over_10d_after": round(100 * (s["resolution_days"] > 10).mean(), 1),
        "reopen_today": round(100 * df["reopened"].mean(), 2),
        "reopen_after": round(100 * expected_reopen.mean(), 2),
        "cases_fixed_docs": int(fix_docs.sum()),
        "cases_fixed_routing": int(fix_route.sum()),
        "fast_track_eligible_pct": round(100 * ((s.amount < 25) | (s.reason.isin(["Duplicate charge", "Credit not processed"])
                                         & (s.amount < 100) & (s.docs_complete_at_intake == 1))).mean(), 1),
    }
    print("\n## scenario\n", json.dumps(out, indent=2))
    return out, s


def charts(df, s, fc, res):
    navy, teal, grey, red = "#1a3a68", "#0f8b8d", "#c9ced6", "#c8553d"
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})

    d = pd.DataFrame(res["02_delay_drivers"])
    fig, ax = plt.subplots(figsize=(8, 3.6))
    lab = d["intake"] + " / " + d["routing"]
    ax.barh(lab, d["avg_days"], color=[red if "missing" in a or "Mis" in a else teal for a in lab])
    for i, (v, sh) in enumerate(zip(d["avg_days"], d["share_pct"])):
        ax.text(v + .2, i, f"{v} days  ({sh}% of cases)", va="center", color=navy)
    ax.invert_yaxis()
    ax.set_xlabel("average resolution days")
    ax.set_title("Missing documents and misrouting drive the slow cases")
    fig.tight_layout()
    fig.savefig(RES / "delay_drivers.png", dpi=150)

    fig, ax = plt.subplots(figsize=(8, 3.6))
    n = len(fc["actual"])
    ax.plot(range(n), fc["actual"], color=navy, label="actual weekly intake")
    ax.plot(range(n - 12, n), fc["backtest"][fc["best"]], color=teal, ls="--", lw=2,
            label=f'{fc["best"]} ({fc["accuracy"][fc["best"]]}% accurate)')
    ax.axvspan(n - 12, n - 1, color=grey, alpha=.3)
    ax.set_ylabel("cases / week")
    ax.set_title("Weekly dispute intake and 12-week forecast backtest")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(RES / "forecast.png", dpi=150)

    fig, ax = plt.subplots(figsize=(8, 3.6))
    bins = np.arange(0, 40, 1)
    ax.hist(df["resolution_days"], bins=bins, color=grey, label="today")
    ax.hist(s["resolution_days"], bins=bins, histtype="step", lw=2, color=teal, label="with intake + routing fixes")
    ax.axvline(10, color=red, ls=":")
    ax.text(10.3, ax.get_ylim()[1] * .9, "10-day SLA", color=red)
    ax.set_xlabel("resolution days")
    ax.set_ylabel("cases")
    ax.legend(frameon=False)
    ax.set_title("Resolution time distribution, before and after")
    fig.tight_layout()
    fig.savefig(RES / "before_after.png", dpi=150)


def main():
    df = pd.read_csv(ROOT / "data" / "disputes.csv")
    res = sql_results(df)
    coef = delay_model(df)
    fc = forecast(df)
    sc, s = scenario(df, coef)
    res.update({"delay_model": {k: float(v) for k, v in coef.items()}, "forecast": fc, "scenario": sc,
                "cases": len(df), "median_days": float(df.resolution_days.median())})
    (RES / "results.json").write_text(json.dumps(res, indent=2, default=float))
    charts(df, s, fc, res)


if __name__ == "__main__":
    main()
