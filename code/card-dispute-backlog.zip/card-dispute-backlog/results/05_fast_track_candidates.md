| reason                   |   cases |   fast_track_eligible |   eligible_pct |   dollars_under_25 |
|:-------------------------|--------:|----------------------:|---------------:|-------------------:|
| Duplicate charge         |    5648 |                  2886 |           51.1 |               8819 |
| Fraud / unauthorized     |   25333 |                  2393 |            9.4 |              39481 |
| Credit not processed     |    6247 |                  2244 |           35.9 |               9635 |
| Merchandise not received |    9171 |                   867 |            9.5 |              14362 |
| Not as described         |    7536 |                   703 |            9.3 |              11619 |
| Incorrect amount         |    3524 |                   335 |            9.5 |               5573 |
