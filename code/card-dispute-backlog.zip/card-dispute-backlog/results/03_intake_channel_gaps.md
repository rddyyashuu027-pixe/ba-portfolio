| intake_channel   |   doc_dependent_cases |   pct_missing_docs |   avg_evidence_requests |
|:-----------------|----------------------:|-------------------:|------------------------:|
| Phone            |                 12006 |               42.6 |                    0.64 |
| Online banking   |                  9057 |               30.6 |                    0.46 |
| Mobile app       |                  5415 |               22.1 |                    0.33 |
