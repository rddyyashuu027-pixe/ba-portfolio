| intake        | routing          |   cases |   share_pct |   avg_days |   avg_evidence_requests |   reopen_rate_pct |
|:--------------|:-----------------|--------:|------------:|-----------:|------------------------:|------------------:|
| Docs missing  | Misrouted        |    1512 |         2.6 |       17.9 |                     1.5 |              15.1 |
| Docs missing  | Routed correctly |    7564 |        13.2 |       15.1 |                     1.5 |              11.4 |
| Docs complete | Misrouted        |    4968 |         8.6 |       12.2 |                     0   |               8.3 |
| Docs complete | Routed correctly |   43415 |        75.6 |        8.1 |                     0   |               4.4 |
