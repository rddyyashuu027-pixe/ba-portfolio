-- Q5. Risk-based prioritization: which low-risk claims could skip full investigation?
-- Rule: amount under $25, or a duplicate / credit-not-processed claim under $100 with docs complete.
SELECT reason,
       COUNT(*)                                                         AS cases,
       SUM(amount < 25 OR (reason IN ('Duplicate charge','Credit not processed')
                           AND amount < 100 AND docs_complete_at_intake = 1)) AS fast_track_eligible,
       ROUND(100.0 * SUM(amount < 25 OR (reason IN ('Duplicate charge','Credit not processed')
                           AND amount < 100 AND docs_complete_at_intake = 1)) / COUNT(*), 1) AS eligible_pct,
       ROUND(SUM(CASE WHEN amount < 25 THEN amount ELSE 0 END), 0)      AS dollars_under_25
FROM disputes
GROUP BY reason
ORDER BY fast_track_eligible DESC;
