-- Q2. Which process failures add time? Docs missing at intake x misrouted to the wrong queue.
SELECT CASE WHEN docs_complete_at_intake = 1 THEN 'Docs complete' ELSE 'Docs missing' END AS intake,
       CASE WHEN misrouted = 1 THEN 'Misrouted' ELSE 'Routed correctly' END             AS routing,
       COUNT(*)                                                AS cases,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1)      AS share_pct,
       ROUND(AVG(resolution_days), 1)                          AS avg_days,
       ROUND(AVG(evidence_requests), 2)                        AS avg_evidence_requests,
       ROUND(100.0 * AVG(reopened), 1)                         AS reopen_rate_pct
FROM disputes
GROUP BY 1, 2
ORDER BY avg_days DESC;
