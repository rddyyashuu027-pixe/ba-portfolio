-- Q1. Is the backlog growing? Monthly intake, average resolution time, share over the 10-day internal SLA.
SELECT substr(opened_date, 1, 7)                                  AS month,
       COUNT(*)                                                   AS cases_opened,
       ROUND(AVG(resolution_days), 1)                             AS avg_resolution_days,
       ROUND(100.0 * SUM(resolution_days > 10) / COUNT(*), 1)     AS pct_over_10_day_sla,
       ROUND(100.0 * AVG(reopened), 1)                            AS reopen_rate_pct
FROM disputes
GROUP BY month
ORDER BY month;
