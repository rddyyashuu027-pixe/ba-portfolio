-- Q3. Where do incomplete claims come from? Only reasons that need merchant documentation.
SELECT intake_channel,
       COUNT(*)                                                     AS doc_dependent_cases,
       ROUND(100.0 * SUM(docs_complete_at_intake = 0) / COUNT(*), 1) AS pct_missing_docs,
       ROUND(AVG(evidence_requests), 2)                              AS avg_evidence_requests
FROM disputes
WHERE reason NOT IN ('Fraud / unauthorized', 'Duplicate charge')
GROUP BY intake_channel
ORDER BY pct_missing_docs DESC;
