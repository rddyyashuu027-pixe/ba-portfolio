-- Q4. Aging buckets by queue, plus regulatory-clock headroom (Reg E 45 days debit, Reg Z 90 days credit).
SELECT queue,
       COUNT(*)                                                         AS cases,
       SUM(resolution_days <= 5)                                        AS d0_5,
       SUM(resolution_days > 5  AND resolution_days <= 10)              AS d6_10,
       SUM(resolution_days > 10 AND resolution_days <= 20)              AS d11_20,
       SUM(resolution_days > 20)                                        AS d20_plus,
       SUM(resolution_days > 0.8 * reg_limit_days)                      AS within_20pct_of_reg_limit
FROM disputes
GROUP BY queue
ORDER BY cases DESC;
