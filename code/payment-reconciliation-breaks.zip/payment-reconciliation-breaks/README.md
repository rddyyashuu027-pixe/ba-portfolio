# Payment Reconciliation Break Analyzer

**Three-way match: core transactions ↔ network settlement ↔ general ledger · SQL · Python**

> Synthetic data (60K transactions, 2 months). Break types are injected on purpose so the SQL has something real to find.

## Problem
Finance and Payments Operations reconcile by hand in spreadsheets every morning. Aged exceptions keep growing, and nobody can say *which kind* of break is driving them. When the cause is unknown, the fix goes to the wrong team.

## Approach
One SQL query ([`analysis.py`](analysis.py)) left-joins all three sources and puts every transaction into exactly one bucket. The order of checks matters: a missing record is classified before an amount difference.

| Break type | Items | % of txns | $ exposure | Who fixes it |
|---|---|---|---|---|
| Timing / cutoff | 468 | 0.78% | $0 (clears itself) | nobody: auto-clear after T+3 |
| Missing settlement | 339 | 0.56% | $33.9K | Network ops |
| **Duplicate GL posting** | 331 | 0.55% | **$29.2K** | Technology (posting logic) |
| Amount mismatch | 282 | 0.47% | $2.8K | Finance (fees / FX) |
| Not posted to GL | 209 | 0.35% | $19.2K | Technology (interface) |

## Insight
**Timing breaks are the largest bucket and carry zero dollar risk.** They should leave the manual queue through an auto-clear rule, so analysts spend their time on the **duplicate and missing GL postings**. Those two are system defects, and one fix removes about $48K of exposure.

## Recommendation
1. Auto-clear timing breaks that match on amount within T+3.
2. Raise a defect for duplicate GL postings with the 331 transaction IDs as evidence.
3. Track a daily break report by type and age (0–2, 3–7, 8–30, 30+ days) in Power BI.

```bash
pip install pandas tabulate && python analysis.py
```
