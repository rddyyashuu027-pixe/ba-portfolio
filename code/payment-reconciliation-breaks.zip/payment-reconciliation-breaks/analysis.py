"""Three-way reconciliation: core transactions vs network settlement vs general ledger.

Synthetic data. Injects the break types operations actually sees, then finds them with SQL.
    python analysis.py
"""
import json
import random
import sqlite3
from datetime import date, timedelta

import pandas as pd

random.seed(11)
txn, stl, gl = [], [], []
for i in range(60_000):
    d = date(2025, 3, 1) + timedelta(days=random.randint(0, 59))
    amt = round(random.lognormvariate(4, 1), 2)
    tid = f"T{i:06d}"
    txn.append((tid, d.isoformat(), amt))
    r = random.random()
    s_amt, s_day, g_amt, g_day, dup = amt, d + timedelta(days=1), amt, d + timedelta(days=1), False
    if r < 0.006:   s_amt = None                                   # missing settlement
    elif r < 0.014: s_day = d + timedelta(days=random.randint(3, 6))  # late settlement past cutoff
    elif r < 0.019: s_amt = round(amt + random.choice([-1, 1]) * random.uniform(.5, 20), 2)  # FX/fee amount mismatch
    elif r < 0.025: dup = True                                      # duplicate GL posting
    elif r < 0.028: g_amt = None                                    # never posted to GL
    if s_amt is not None: stl.append((tid, s_day.isoformat(), s_amt))
    if g_amt is not None:
        gl.append((tid, g_day.isoformat(), g_amt))
        if dup: gl.append((tid, (g_day + timedelta(days=1)).isoformat(), g_amt))

con = sqlite3.connect(":memory:")
for name, rows in (("core_txn", txn), ("settlement", stl), ("gl_postings", gl)):
    pd.DataFrame(rows, columns=["txn_id", "post_date", "amount"]).to_sql(name, con, index=False)

BREAKS = """
WITH g AS (SELECT txn_id, COUNT(*) AS gl_rows, SUM(amount) AS gl_amt, MIN(post_date) AS gl_date
           FROM gl_postings GROUP BY txn_id),
m AS (
  SELECT t.txn_id, t.post_date, t.amount, s.amount AS stl_amt, s.post_date AS stl_date, g.gl_rows, g.gl_amt,
    CASE WHEN s.txn_id IS NULL                                   THEN 'Missing settlement'
         WHEN g.txn_id IS NULL                                   THEN 'Not posted to GL'
         WHEN g.gl_rows > 1                                      THEN 'Duplicate GL posting'
         WHEN ABS(s.amount - t.amount) > 0.01                    THEN 'Amount mismatch'
         WHEN julianday(s.post_date) - julianday(t.post_date) > 2 THEN 'Timing / cutoff'
         ELSE 'Matched' END AS break_type
  FROM core_txn t
  LEFT JOIN settlement s USING (txn_id)
  LEFT JOIN g USING (txn_id))
SELECT break_type, COUNT(*) AS items,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct,
       ROUND(SUM(ABS(COALESCE(gl_amt, 0) - amount) + ABS(COALESCE(stl_amt, 0) - amount)), 0) AS dollar_exposure
FROM m GROUP BY break_type ORDER BY items DESC
"""
res = pd.read_sql(BREAKS, con)
print(res.to_markdown(index=False))
open("results.json", "w").write(json.dumps(res.to_dict("records"), indent=2))
