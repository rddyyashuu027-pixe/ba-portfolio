"""Digital deposit account onboarding funnel: drop-off and time-in-stage. Synthetic data.
    python analysis.py
"""
import json
import random
import sqlite3

import pandas as pd

random.seed(5)
STAGES = ["Application submitted", "Identity verified", "KYC / CIP review", "Account funded", "First transaction"]
rows = []
for i in range(80_000):
    ch = random.choices(["Mobile", "Web", "Branch-assisted"], [55, 35, 10])[0]
    t = 0.0
    manual = random.random() < (0.22 if ch != "Branch-assisted" else 0.08)
    for s, stage in enumerate(STAGES):
        rows.append((f"N{i:06d}", ch, s, stage, round(t, 1), int(manual)))
        cont = [0.86, 0.93 if not manual else 0.80, 0.78, 0.88][s] if s < 4 else 0
        if s == 4 or random.random() > cont:
            break
        t += [random.uniform(.05, .5), (random.uniform(20, 70) if manual else random.uniform(.1, 2)),
              random.uniform(2, 30), random.uniform(5, 120)][s]

con = sqlite3.connect(":memory:")
pd.DataFrame(rows, columns=["app_id", "channel", "stage_no", "stage", "hours_from_start", "manual_review"]).to_sql("events", con)
q = {
 "funnel": """SELECT stage_no, stage, COUNT(*) AS applicants,
     ROUND(100.0*COUNT(*)/FIRST_VALUE(COUNT(*)) OVER (ORDER BY stage_no),1) AS pct_of_start,
     ROUND(100.0*COUNT(*)/LAG(COUNT(*)) OVER (ORDER BY stage_no),1) AS step_conversion_pct
     FROM events GROUP BY stage_no, stage ORDER BY stage_no""",
 "manual_review_impact": """SELECT CASE manual_review WHEN 1 THEN 'Manual KYC review' ELSE 'Auto-decisioned' END AS path,
     COUNT(DISTINCT app_id) AS applicants,
     ROUND(100.0*SUM(stage_no=3)/COUNT(DISTINCT app_id),1) AS pct_funded,
     ROUND(AVG(CASE WHEN stage_no=2 THEN hours_from_start END),1) AS avg_hours_to_kyc
     FROM events GROUP BY 1""",
 "by_channel": """SELECT channel, COUNT(DISTINCT app_id) AS applicants,
     ROUND(100.0*SUM(stage_no=4)/COUNT(DISTINCT app_id),1) AS pct_active
     FROM events GROUP BY 1 ORDER BY pct_active""",
}
out = {}
for name, sql in q.items():
    df = pd.read_sql(sql, con)
    out[name] = df.to_dict("records")
    print(f"\n## {name}\n" + df.to_markdown(index=False))
open("results.json", "w").write(json.dumps(out, indent=2))
