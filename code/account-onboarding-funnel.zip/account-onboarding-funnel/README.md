# Digital Account Onboarding Funnel

**Funnel & time-in-stage analysis · SQL window functions · KYC / CIP**

> Synthetic data: 80K digital deposit account applications.

## Problem
Marketing pays to bring applicants in, but only about half end up as active customers. Product wants to know **where people drop off** and whether the **manual KYC review queue** is the cause.

## Funnel
| Stage | Applicants | % of start | Step conversion |
|---|---|---|---|
| Application submitted | 80,000 | 100% | |
| Identity verified | 68,696 | 85.9% | 85.9% |
| KYC / CIP review passed | 61,987 | 77.5% | 90.2% |
| **Account funded** | 48,355 | 60.4% | **78.0%** ← biggest leak |
| First transaction | 42,629 | 53.3% | 88.2% |

## Manual review effect
| Path | Applicants | Funded | Avg hours to KYC decision |
|---|---|---|---|
| Auto-decisioned | 63,501 | 62.4% | 1.3 h |
| Manual KYC review | 16,499 | **53.1%** | **45.3 h** |

## Insight
Applicants who wait nearly two days for manual review fund **9 points less often**. They lose momentum and open an account somewhere else. Channel makes almost no difference (53% active everywhere), so this is a **process problem, not a channel problem**.

## Recommendation
1. Review which manual-review triggers seldom result in a decline. Those can be auto-approved, with Compliance sign-off.
2. Send a "fund your account" nudge right after approval, with instant-verification funding.
3. Track the KPI as **% funded within 7 days of application**.

```bash
pip install pandas tabulate && python analysis.py
```
