# Healthcare Claim Denial Root Cause (X12 835 CARC codes)

**Revenue cycle analytics · SQL · Python · CARC/RARC denial codes**

> Synthetic data: 140K claims across 5 payers and 5 departments.

## Problem
Denied claims delay cash and cost rework. Billing teams appeal denials one by one, and nobody measures **how many denials were preventable at the front end**.

## Findings
- Overall denial rate is **7.17%**. **4.97 points (69% of denials) are preventable**: missing information, no prior auth, duplicates, or timely filing.
- **CO-16, missing / invalid claim information, is 41% of all denials** and $2.8M billed at risk.
- **Emergency has double the missing-field rate** (5.9% vs about 3%) because registration happens under time pressure.

| CARC | Description | Preventable | Share |
|---|---|---|---|
| CO-16 | Missing / invalid claim info | ✅ | 41.2% |
| CO-197 | Prior authorization absent | ✅ | 15.4% |
| CO-50 | Not medically necessary | ❌ | 11.8% |
| CO-97 | Bundled service | ❌ | 10.7% |
| PR-1 | Patient deductible | ❌ | 8.2% |
| CO-18 | Duplicate claim | ✅ | 7.2% |
| CO-29 | Timely filing | ✅ | 5.5% |

## Recommendation
1. Add claim-scrubber edits for the CO-16 fields that are most often missing, before the 837 goes out.
2. Run a post-visit registration completeness check in Emergency.
3. Track preventable denial rate as the KPI, not total denial rate. Total includes things billing can't control.

```bash
pip install pandas tabulate && python analysis.py
```
