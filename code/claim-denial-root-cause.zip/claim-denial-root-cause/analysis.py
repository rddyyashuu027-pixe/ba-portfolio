"""Healthcare claim denial root cause using X12 835 CARC codes. Synthetic data.
    python analysis.py
"""
import json
import random
import sqlite3

import pandas as pd

random.seed(3)
CARC = {  # code: (description, preventable at front end?, weight)
    "CO-16": ("Missing / invalid claim information", 1, 30),
    "CO-197": ("Precertification / authorization absent", 1, 18),
    "CO-18": ("Duplicate claim", 1, 9),
    "CO-29": ("Timely filing limit expired", 1, 7),
    "CO-50": ("Not medically necessary", 0, 14),
    "CO-97": ("Bundled into another service", 0, 12),
    "PR-1": ("Patient deductible", 0, 10),
}
PAYERS = ["Medicare", "Medicaid", "Commercial A", "Commercial B", "Commercial C"]
rows = []
for i in range(140_000):
    payer = random.choice(PAYERS)
    dept = random.choice(["Radiology", "Cardiology", "Emergency", "Orthopedics", "Primary Care"])
    missing_field = random.random() < (0.06 if dept == "Emergency" else 0.03)
    p_deny = 0.055 + 0.35 * missing_field + (0.02 if payer == "Medicaid" else 0)
    code = ""
    if random.random() < p_deny:
        code = "CO-16" if missing_field and random.random() < .7 else \
            random.choices(list(CARC), [v[2] for v in CARC.values()])[0]
    rows.append((f"C{i:06d}", payer, dept, int(missing_field), code, round(random.lognormvariate(6, 1), 2)))

con = sqlite3.connect(":memory:")
pd.DataFrame(rows, columns=["claim_id", "payer", "department", "missing_field", "carc", "billed"]).to_sql("claims", con)
pd.DataFrame([(k, *v[:2]) for k, v in CARC.items()], columns=["carc", "description", "preventable"]).to_sql("carc", con)

q = {
 "denial_by_carc": """SELECT c.carc, r.description, r.preventable, COUNT(*) AS denials,
        ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER(),1) AS share_pct, ROUND(SUM(billed)) AS billed_at_risk
        FROM claims c JOIN carc r USING(carc) GROUP BY 1,2,3 ORDER BY denials DESC""",
 "preventable_rate": """SELECT ROUND(100.0*SUM(carc<>'')/COUNT(*),2) AS denial_rate_pct,
        ROUND(100.0*SUM(r.preventable=1)/COUNT(*),2) AS preventable_denial_rate_pct
        FROM claims c LEFT JOIN carc r USING(carc)""",
 "by_department": """SELECT department, COUNT(*) AS claims, ROUND(100.0*AVG(missing_field),1) AS pct_missing_field,
        ROUND(100.0*SUM(carc='CO-16')/COUNT(*),2) AS co16_rate_pct
        FROM claims GROUP BY 1 ORDER BY co16_rate_pct DESC""",
}
out = {}
for name, sql in q.items():
    df = pd.read_sql(sql, con)
    out[name] = df.to_dict("records")
    print(f"\n## {name}\n" + df.to_markdown(index=False))
open("results.json", "w").write(json.dumps(out, indent=2))
