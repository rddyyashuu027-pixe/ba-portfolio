"""Generate a synthetic ACH debit origination + returns dataset.

Nothing here is real bank data. Return-code behaviour is modelled on how NACHA
return reason codes typically behave (R01 NSF dominates; R02/R03/R04 spike on
first debits to accounts that were never validated; unauthorized codes are
higher on WEB and TEL entries). Run:  python generate_data.py
"""
import csv
import random
from datetime import date, timedelta
from pathlib import Path

random.seed(42)
OUT = Path(__file__).parent / "data"
OUT.mkdir(exist_ok=True)

N_ACCOUNTS = 140_000
START, MONTHS = date(2025, 1, 1), 6

CHANNELS = [  # channel, SEC code, share of new enrollments
    ("Online Enrollment", "WEB", 0.38),
    ("Mobile App", "WEB", 0.22),
    ("Recurring Biller File", "PPD", 0.30),
    ("Phone Agent", "TEL", 0.06),
    ("Branch", "PPD", 0.04),
]
# share of accounts verified (prenote or real-time account validation) before 1st debit
VALIDATED_SHARE = {"Online Enrollment": 0.30, "Mobile App": 0.45,
                   "Recurring Biller File": 0.85, "Phone Agent": 0.25, "Branch": 0.95}
UNAUTH_BASE = {"WEB": 0.0026, "TEL": 0.0042, "PPD": 0.0009}


def pick_return(first, validated, sec):
    """Return a NACHA return code or '' for a settled entry."""
    r = random.random()
    p = 0.0
    # Administrative: account closed / no account / invalid account number
    admin = {"R02": 0.0016, "R03": 0.0004, "R04": 0.0003}
    if first and not validated:
        admin = {"R02": 0.0035, "R03": 0.0290, "R04": 0.0190}
    elif first and validated:
        admin = {"R02": 0.0020, "R03": 0.0012, "R04": 0.0008}
    for code, prob in admin.items():
        p += prob
        if r < p:
            return code
    p += 0.0172 * (1.35 if first else 1.0)  # R01 insufficient funds
    if r < p:
        return "R01"
    p += 0.0009  # R16 account frozen / R20 non-transaction account
    if r < p:
        return random.choice(["R16", "R20"])
    u = UNAUTH_BASE[sec] * (1.6 if first and not validated else 1.0)
    p += u
    if r < p:
        return random.choices(["R10", "R05", "R07", "R11", "R29"], [50, 10, 15, 15, 10])[0]
    return ""


def main():
    accounts = []
    for i in range(N_ACCOUNTS):
        ch, sec, _ = random.choices(CHANNELS, [c[2] for c in CHANNELS])[0]
        validated = random.random() < VALIDATED_SHARE[ch]
        enroll = START + timedelta(days=random.randint(-120, 30 * MONTHS - 5))
        amount = round(min(4800, random.lognormvariate(4.7, 0.8)), 2)
        accounts.append((f"A{i:06d}", ch, sec, validated, enroll, amount))

    rows = []
    entry_id = 0
    for acct_id, ch, sec, validated, enroll, amount in accounts:
        d = enroll
        n = 0
        while d < START + timedelta(days=30 * MONTHS):
            if d >= START:
                first = n == 0 and enroll >= START
                code = pick_return(first, validated, sec)
                entry_id += 1
                rows.append([f"E{entry_id:07d}", acct_id, d.isoformat(), ch, sec,
                             int(validated), int(first), round(amount * random.uniform(.9, 1.1), 2),
                             code, (d + timedelta(days=random.randint(1, 3))).isoformat() if code else ""])
                if code in ("R02", "R03", "R04", "R16", "R20", "R07", "R10", "R05", "R29", "R11"):
                    break  # originator stops debiting a dead / disputed account
            n += 1
            d += timedelta(days=30 + random.randint(-2, 2))

    with open(OUT / "ach_entries.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["entry_id", "account_id", "effective_date", "origination_channel", "sec_code",
                    "account_validated", "first_debit", "amount", "return_code", "return_date"])
        w.writerows(rows)

    with open(OUT / "return_codes.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["return_code", "description", "return_category"])
        w.writerows([
            ["R01", "Insufficient funds", "NSF"],
            ["R02", "Account closed", "Administrative"],
            ["R03", "No account / unable to locate", "Administrative"],
            ["R04", "Invalid account number", "Administrative"],
            ["R05", "Unauthorized consumer debit (corporate SEC)", "Unauthorized"],
            ["R07", "Authorization revoked by customer", "Unauthorized"],
            ["R10", "Customer advises not authorized", "Unauthorized"],
            ["R11", "Customer advises entry not in accordance with authorization", "Unauthorized"],
            ["R29", "Corporate customer advises not authorized", "Unauthorized"],
            ["R16", "Account frozen", "Other"],
            ["R20", "Non-transaction account", "Other"],
        ])
    print(f"wrote {len(rows):,} entries for {N_ACCOUNTS:,} accounts -> {OUT}")


if __name__ == "__main__":
    main()
