"""Run every SQL file in sql/ against the synthetic data and build the business case.

    python generate_data.py && python analyze.py

Writes results/results.json, results/*.md tables and results/*.png charts.
"""
import csv
import json
import sqlite3
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = Path(__file__).parent
RES = ROOT / "results"
RES.mkdir(exist_ok=True)

# Business-case assumptions. Change these to your bank's numbers.
COST_PER_RETURN = 4.50      # ops handling + re-presentment + customer contact, USD
COST_PER_VALIDATION = 0.20  # real-time account validation vendor fee, USD


def load(con):
    for name in ("ach_entries", "return_codes"):
        with open(ROOT / "data" / f"{name}.csv") as f:
            r = csv.reader(f)
            cols = next(r)
            types = {"account_validated": "INTEGER", "first_debit": "INTEGER", "amount": "REAL"}
            con.execute(f"CREATE TABLE {name} ({', '.join(f'{c} {types.get(c, 'TEXT')}' for c in cols)})")
            con.executemany(f"INSERT INTO {name} VALUES ({', '.join('?' * len(cols))})", r)
    con.execute("CREATE INDEX ix ON ach_entries(origination_channel)")


def run(con, path):
    cur = con.execute(path.read_text())
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]


def md(rows):
    cols = list(rows[0])
    out = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    out += ["| " + " | ".join(str(r[c]) for c in cols) + " |" for r in rows]
    return "\n".join(out)


def main():
    con = sqlite3.connect(":memory:")
    load(con)
    results = {}
    for sql in sorted((ROOT / "sql").glob("*.sql")):
        rows = run(con, sql)
        results[sql.stem] = rows
        (RES / f"{sql.stem}.md").write_text(md(rows) + "\n")
        print(f"\n## {sql.stem}\n{md(rows[:12])}")

    sim = results["05_rule_simulation"][0]
    months = len(results["01_monthly_return_rate"])
    avoided = sim["returns_today"] - sim["returns_with_rule"]
    case = {
        "months": months,
        "returns_avoided_per_month": round(avoided / months),
        "validations_per_month": round(sim["entries_needing_validation"] / months),
        "annual_return_cost_avoided": round(avoided / months * 12 * COST_PER_RETURN),
        "annual_validation_cost": round(sim["entries_needing_validation"] / months * 12 * COST_PER_VALIDATION),
    }
    case["annual_net_benefit"] = case["annual_return_cost_avoided"] - case["annual_validation_cost"]
    # Break-even: the all-in cost of one return at which the rule pays for itself.
    case["breakeven_cost_per_return"] = round(COST_PER_VALIDATION * sim["entries_needing_validation"] / avoided, 2)
    case["sensitivity_annual_net"] = {
        f"${c:.2f}/return": round(avoided / months * 12 * c - case["annual_validation_cost"])
        for c in (COST_PER_RETURN, 10.0, 15.0, 25.0)
    }
    results["business_case"] = case
    print("\n## business case\n" + json.dumps(case, indent=2))
    (RES / "results.json").write_text(json.dumps(results, indent=2))
    charts(results)


def charts(results):
    navy, teal, grey, red = "#1a3a68", "#0f8b8d", "#c9ced6", "#c8553d"
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})

    p = results["02_return_code_pareto"]
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.bar([r["return_code"] for r in p], [r["returns"] for r in p],
           color=[red if r["return_category"] == "Administrative" else navy for r in p])
    ax2 = ax.twinx()
    ax2.plot([r["return_code"] for r in p], [r["cumulative_pct"] for r in p], color=teal, marker="o")
    ax2.set_ylim(0, 105)
    ax2.set_ylabel("cumulative %")
    ax.set_ylabel("returns")
    ax.set_title("Return code Pareto (red = administrative, preventable with validation)")
    fig.tight_layout()
    fig.savefig(RES / "pareto.png", dpi=150)

    seg = [r for r in results["04_channel_by_validation"] if r["debit_type"] == "First debit"]
    fig, ax = plt.subplots(figsize=(8, 4))
    labels = [f'{r["origination_channel"]}\n{r["validation"]}' for r in seg]
    ax.barh(labels, [r["admin_return_pct"] for r in seg],
            color=[red if r["validation"] == "Not validated" else teal for r in seg])
    ax.invert_yaxis()
    ax.set_xlabel("administrative return rate on first debits, %")
    ax.set_title("Unvalidated first debits are the root cause")
    fig.tight_layout()
    fig.savefig(RES / "root_cause.png", dpi=150)

    sim = results["05_rule_simulation"][0]
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.bar(["Today", "With validation rule"],
           [sim["return_rate_today_pct"], sim["return_rate_with_rule_pct"]], color=[grey, teal])
    for i, v in enumerate([sim["return_rate_today_pct"], sim["return_rate_with_rule_pct"]]):
        ax.text(i, v + .03, f"{v}%", ha="center", fontweight="bold", color=navy)
    ax.set_ylabel("overall ACH return rate, %")
    fig.tight_layout()
    fig.savefig(RES / "before_after.png", dpi=150)


if __name__ == "__main__":
    main()
