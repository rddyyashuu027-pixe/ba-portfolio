| entries | returns_today | returns_with_rule | return_rate_today_pct | return_rate_with_rule_pct | entries_needing_validation |
|---|---|---|---|---|---|
| 623142 | 16735 | 14659.0 | 2.69 | 2.35 | 39950 |
