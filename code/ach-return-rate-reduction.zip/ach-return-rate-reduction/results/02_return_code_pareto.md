| return_code | description | return_category | returns | share_pct | cumulative_pct |
|---|---|---|---|---|---|
| R01 | Insufficient funds | NSF | 11294 | 67.5 | 67.5 |
| R03 | No account / unable to locate | Administrative | 1402 | 8.4 | 75.9 |
| R02 | Account closed | Administrative | 1146 | 6.8 | 82.7 |
| R04 | Invalid account number | Administrative | 947 | 5.7 | 88.4 |
| R10 | Customer advises not authorized | Unauthorized | 662 | 4.0 | 92.3 |
| R16 | Account frozen | Other | 306 | 1.8 | 94.2 |
| R20 | Non-transaction account | Other | 297 | 1.8 | 95.9 |
| R11 | Customer advises entry not in accordance with authorization | Unauthorized | 232 | 1.4 | 97.3 |
| R07 | Authorization revoked by customer | Unauthorized | 188 | 1.1 | 98.4 |
| R05 | Unauthorized consumer debit (corporate SEC) | Unauthorized | 133 | 0.8 | 99.2 |
| R29 | Corporate customer advises not authorized | Unauthorized | 128 | 0.8 | 100.0 |
