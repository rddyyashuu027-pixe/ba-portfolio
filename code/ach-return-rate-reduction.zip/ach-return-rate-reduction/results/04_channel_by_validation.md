| origination_channel | debit_type | validation | entries | admin_returns | admin_return_pct | total_return_pct |
|---|---|---|---|---|---|---|
| Online Enrollment | First debit | Not validated | 22109 | 1133 | 5.12 | 8.16 |
| Mobile App | First debit | Not validated | 10123 | 537 | 5.3 | 8.45 |
| Online Enrollment | Repeat debit | Not validated | 141827 | 354 | 0.25 | 2.28 |
| Recurring Biller File | Repeat debit | Validated | 139353 | 301 | 0.22 | 2.09 |
| Recurring Biller File | First debit | Not validated | 3778 | 208 | 5.51 | 8.13 |
| Mobile App | Repeat debit | Not validated | 64563 | 174 | 0.27 | 2.38 |
| Phone Agent | First debit | Not validated | 3758 | 172 | 4.58 | 7.69 |
| Online Enrollment | Repeat debit | Validated | 61697 | 126 | 0.2 | 2.29 |
| Mobile App | Repeat debit | Validated | 53879 | 122 | 0.23 | 2.38 |
| Recurring Biller File | First debit | Validated | 21222 | 78 | 0.37 | 2.92 |
| Branch | Repeat debit | Validated | 21230 | 63 | 0.3 | 2.1 |
| Recurring Biller File | Repeat debit | Not validated | 23985 | 55 | 0.23 | 2.12 |
| Phone Agent | Repeat debit | Not validated | 23740 | 51 | 0.21 | 2.58 |
| Mobile App | First debit | Validated | 8218 | 39 | 0.47 | 3.24 |
| Online Enrollment | First debit | Validated | 9505 | 31 | 0.33 | 2.9 |
| Phone Agent | Repeat debit | Validated | 8341 | 26 | 0.31 | 2.35 |
| Branch | First debit | Validated | 3173 | 7 | 0.22 | 2.62 |
| Phone Agent | First debit | Validated | 1317 | 5 | 0.38 | 3.04 |
| Branch | Repeat debit | Not validated | 1142 | 2 | 0.18 | 2.8 |
