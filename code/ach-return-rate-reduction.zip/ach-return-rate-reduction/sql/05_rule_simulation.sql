-- Q5. What if every first debit had to pass account validation before origination?
-- Re-score unvalidated first debits at the return rate we observe for validated first
-- debits in the same channel (a like-for-like counterfactual, not a guarantee).
WITH rates AS (
  SELECT origination_channel,
         1.0 * SUM(return_code <> '') / COUNT(*) AS validated_first_rate
  FROM ach_entries
  WHERE first_debit = 1 AND account_validated = 1
  GROUP BY origination_channel
),
scored AS (
  SELECT e.*,
         CASE WHEN e.first_debit = 1 AND e.account_validated = 0
              THEN r.validated_first_rate
              ELSE (e.return_code <> '') END AS expected_return
  FROM ach_entries e
  JOIN rates r USING (origination_channel)
)
SELECT COUNT(*)                                              AS entries,
       SUM(return_code <> '')                                AS returns_today,
       ROUND(SUM(expected_return))                           AS returns_with_rule,
       ROUND(100.0 * SUM(return_code <> '') / COUNT(*), 2)   AS return_rate_today_pct,
       ROUND(100.0 * SUM(expected_return) / COUNT(*), 2)     AS return_rate_with_rule_pct,
       SUM(first_debit = 1 AND account_validated = 0)        AS entries_needing_validation
FROM scored;
