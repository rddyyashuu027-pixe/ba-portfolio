-- Q1. What is our return rate, and is it stable month to month?
SELECT substr(effective_date, 1, 7)                          AS month,
       COUNT(*)                                              AS entries,
       SUM(return_code <> '')                                AS returns,
       ROUND(100.0 * SUM(return_code <> '') / COUNT(*), 2)   AS return_rate_pct
FROM ach_entries
GROUP BY month
ORDER BY month;
