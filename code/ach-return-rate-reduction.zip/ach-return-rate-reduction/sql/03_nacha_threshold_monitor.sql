-- Q3. Are we inside NACHA return-rate thresholds?
-- Unauthorized (R05,R07,R10,R11,R29) 0.5% | Administrative (R02,R03,R04) 3.0% | Overall 15.0%
SELECT substr(e.effective_date, 1, 7) AS month,
       ROUND(100.0 * SUM(c.return_category = 'Unauthorized')   / COUNT(*), 3) AS unauthorized_pct,
       ROUND(100.0 * SUM(c.return_category = 'Administrative') / COUNT(*), 3) AS administrative_pct,
       ROUND(100.0 * SUM(e.return_code <> '')                  / COUNT(*), 3) AS overall_pct
FROM ach_entries e
LEFT JOIN return_codes c ON c.return_code = e.return_code
GROUP BY month
ORDER BY month;
