-- Q2. Which return codes drive the volume? (Pareto with running share)
WITH by_code AS (
  SELECT e.return_code, c.description, c.return_category, COUNT(*) AS returns
  FROM ach_entries e
  JOIN return_codes c ON c.return_code = e.return_code
  GROUP BY e.return_code, c.description, c.return_category
)
SELECT return_code, description, return_category, returns,
       ROUND(100.0 * returns / SUM(returns) OVER (), 1)                                   AS share_pct,
       ROUND(100.0 * SUM(returns) OVER (ORDER BY returns DESC) / SUM(returns) OVER (), 1) AS cumulative_pct
FROM by_code
ORDER BY returns DESC;
