-- Q4. Root cause: where do administrative returns concentrate?
-- Cut by origination channel x first debit x whether the account was validated.
SELECT e.origination_channel,
       CASE WHEN e.first_debit = 1 THEN 'First debit' ELSE 'Repeat debit' END   AS debit_type,
       CASE WHEN e.account_validated = 1 THEN 'Validated' ELSE 'Not validated' END AS validation,
       COUNT(*)                                                                   AS entries,
       SUM(c.return_category = 'Administrative')                                  AS admin_returns,
       ROUND(100.0 * SUM(c.return_category = 'Administrative') / COUNT(*), 2)     AS admin_return_pct,
       ROUND(100.0 * SUM(e.return_code <> '') / COUNT(*), 2)                      AS total_return_pct
FROM ach_entries e
LEFT JOIN return_codes c ON c.return_code = e.return_code
GROUP BY 1, 2, 3
HAVING COUNT(*) > 500
ORDER BY admin_returns DESC;
