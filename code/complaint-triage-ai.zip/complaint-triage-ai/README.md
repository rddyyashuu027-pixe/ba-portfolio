# AI Complaint Triage: Route Complaints and Catch the Risky Ones

**AI / NLP · Python · scikit-learn · human-in-the-loop design**

> 12K synthetic complaints generated from templates in 6 product areas. Runs offline: no API keys, no customer data.

## The problem

A bank's complaint team reads every complaint by hand to decide two things: **which team gets it** (cards, ACH, fees, mortgage…) and **does compliance need to see it** (possible Reg E error claims, discrimination, elder abuse, misleading sales). That's about 3.5 minutes per complaint. The risky ones sometimes sit in the wrong queue for days.

## What I built

1. **Router:** reads the complaint text and picks the product team (TF-IDF + logistic regression).
2. **Compliance flagger:** a second model tuned to catch risky complaints, with a low threshold on purpose because a missed one costs more than a false alarm.
3. **Confidence gate:** only complaints the model is at least 80% sure about get routed automatically. Everything else goes to a person.

## The honest part: testing it properly

My first test said **100% accurate**. That was wrong. The test complaints used the same sentences the model trained on. Real customers write things you've never seen ("my paycheck never hit my acct"), so I rebuilt the test set with **wordings that never appear in training**, plus typos and shorthand.

| Version | What changed | Accuracy on realistic test |
|---|---|---|
| v1 | words only | 68.1% |
| v2 | + character pieces (handles typos) | 68.6% |
| **v3** | + one month of agent corrections fed back in | **84.4%** |

Typo handling barely helped. The real gap was **new ways of saying things**: 96% accurate on familiar wording vs. 68% on wording it still hasn't seen. The thing that actually moved the number was the **feedback loop**, where agents' fixes become training data.

## Results (v3)

| Metric | Value |
|---|---|
| Routed automatically (confidence ≥ 80%) | **80.9%** of complaints |
| Accuracy on those | **89.1%** |
| Sent to a person | 19.1% |
| Compliance flag: precision | 100% (no false alarms) |
| Compliance flag: recall | **70.4%** ⚠️ |
| Analyst time saved | ~**364 hours / month** at 9,000 complaints |

## What I'd recommend

1. **Launch routing with the confidence gate.** Low-confidence complaints go to people, and every correction they make is logged as training data. Retrain monthly.
2. **Don't let the AI be the only compliance net.** 70% recall means about 3 in 10 risky complaints would be missed. Keep the keyword rules and spot-checks compliance already uses, and add the model on top as a second net, not a replacement.
3. **Track two numbers monthly:** accuracy on complaints agents corrected, and flag recall on a sample compliance reviews by hand.

## Requirements sketch

- *As a complaint analyst, I want low-confidence complaints in my queue with the model's best guess shown, so I can confirm or fix it in one click.*
- *As a compliance officer, I want any complaint the model OR the keyword rules flag to land in my queue within 1 business day.*
- Every routing decision stores: model version, confidence, final team, and who changed it (audit trail).

## Run it

```bash
pip install pandas numpy scikit-learn
python complaint_triage.py
```
