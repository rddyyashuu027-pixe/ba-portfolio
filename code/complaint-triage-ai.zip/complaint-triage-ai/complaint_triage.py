"""AI complaint triage: read a customer complaint, route it, and flag the risky ones.

Synthetic complaint text (12K) written from templates across 6 products. A TF-IDF + logistic
regression classifier routes each complaint to the right team, and a second model flags
complaints that need compliance review (possible Reg E error claims, discrimination, elder
abuse, UDAAP language). Runs offline: no API keys, no customer data.

    python complaint_triage.py
"""
import json
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline

random.seed(4)
RES = Path(__file__).parent / "results"
RES.mkdir(exist_ok=True)

PRODUCTS = {
    "Card disputes": ["I was charged {amt} at a merchant I never visited", "my dispute for the {amt} charge has been open for weeks",
                      "the merchant never sent my order and I want my {amt} back", "there is a duplicate charge of {amt} on my card",
                      "the refund the store promised never showed up on my card"],
    "ACH & transfers": ["my direct deposit did not arrive today", "an ACH debit of {amt} came out twice",
                        "a company keeps debiting my account after I cancelled", "my transfer to another bank is stuck pending",
                        "the payment I set up was returned and I was charged a fee"],
    "Fees": ["I was charged an overdraft fee of {amt} even though I had money", "monthly maintenance fee charged again",
             "why do I keep getting {amt} in fees", "the fee was supposed to be waived with direct deposit",
             "I got hit with three overdraft fees in one day"],
    "Account opening": ["my new account application has been under review for days", "you asked me to upload my ID again",
                        "I can not log in to fund my new account", "the account was opened but my debit card never came",
                        "verification keeps failing on my application"],
    "Mortgage & loans": ["my escrow payment went up with no explanation", "the loan payoff amount is wrong",
                         "my mortgage payment was applied to the wrong month", "I applied for a hardship plan and nobody called back",
                         "the interest rate on my loan changed"],
    "Wealth & investing": ["my portfolio is much riskier than what I signed up for", "my advisor never rebalanced my account",
                           "I was sold a fund with high fees without explanation", "my statement shows a position I did not buy",
                           "the trade I placed was executed late"],
}
FLAGS = {  # phrases that should trigger compliance review
    "Reg E error claim": ["I did not authorize this transfer", "this electronic transfer was an error", "someone took money from my account without permission"],
    "Discrimination": ["I was treated differently because of my race", "they denied me because of my age", "the banker made comments about my religion"],
    "Elder / vulnerable": ["my elderly mother was pressured into this", "someone is taking advantage of my grandfather", "my father has dementia and they still opened this"],
    "UDAAP / misleading": ["this was advertised as free and it was not", "the banker lied to me about the terms", "I was misled about the fees"],
}
UNSEEN = {  # wordings held out of training entirely
    "Card disputes": ["there's a charge from some store I've never heard of", "still waiting on the chargeback for that purchase"],
    "ACH & transfers": ["my paycheck never hit my account", "money I sent to my other bank vanished"],
    "Fees": ["you guys charged me for going negative by two dollars", "why am I paying a monthly charge on this account"],
    "Account opening": ["can't finish signing up, it keeps asking for documents", "approved but no card in the mail after two weeks"],
    "Mortgage & loans": ["my house payment jumped and nobody told me why", "payoff letter has the wrong number"],
    "Wealth & investing": ["my retirement account is way more aggressive than I asked for", "nobody has touched my investments in two years"],
}
UNSEEN_FLAGS = {
    "Reg E error claim": ["there's a withdrawal I never made"],
    "Discrimination": ["I think they turned me down because I'm a woman"],
    "Elder / vulnerable": ["my 82 year old dad got talked into this by the banker"],
    "UDAAP / misleading": ["they told me there were no fees, that was false"],
}


def noisy(s):
    """Real complaints have typos, shorthand and dropped words."""
    swaps = {"account": "acct", "you": "u", "please": "pls", "because": "bc", "with": "w/", "charged": "chrged", "never": "nevr"}
    w = s.split()
    for i, x in enumerate(w):
        r = random.random()
        if x.lower() in swaps and r < .3: w[i] = swaps[x.lower()]
        elif len(x) > 4 and r < .05: j = random.randrange(1, len(x) - 1); w[i] = x[:j] + x[j + 1:]
    if len(w) > 6 and random.random() < .3: w.pop(random.randrange(len(w)))
    return " ".join(w)


TONE = ["", "This is ridiculous. ", "Please help. ", "I have called three times. ", "Very frustrated. ", ""]
END = ["", " Please fix this.", " I want this resolved now.", " I am thinking about closing my account.", " Thank you."]


def make(n, test=False, only_first=False):
    rows = []
    for _ in range(n):
        prod = random.choice(list(PRODUCTS))
        extra = UNSEEN[prod][:1] if only_first else UNSEEN[prod]
        pool = PRODUCTS[prod] + (extra * 3 if test else [])
        text = random.choice(TONE) + random.choice(pool).format(amt=f"${random.randint(5, 2500)}")
        if random.random() < .35:  # customers often mention a second topic
            other = random.choice([p for p in PRODUCTS if p != prod])
            text += " and also " + random.choice(PRODUCTS[other]).format(amt=f"${random.randint(5, 900)}").lower()
        flag = ""
        if random.random() < .09:
            flag = random.choice(list(FLAGS))
            text += ". " + random.choice(FLAGS[flag] + (([] if only_first else UNSEEN_FLAGS[flag]) * 2 if test else []))
        rows.append((noisy(text + random.choice(END)), prod, flag))
    return pd.DataFrame(rows, columns=["complaint_text", "product", "compliance_flag"])


tr, te = make(9_000), make(3_000, test=True)   # test set includes wordings never seen in training
df = pd.concat([tr, te])

# v1: whole words. v2: word + character pieces, so typos and shorthand still match.
from sklearn.pipeline import make_union
v1 = make_pipeline(TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True), LogisticRegression(max_iter=2000, C=4))
v1.fit(tr.complaint_text, tr["product"])
v1_acc = (v1.predict(te.complaint_text) == te["product"]).mean()
router = make_pipeline(make_union(TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True),
                                  TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=2, sublinear_tf=True)),
                       LogisticRegression(max_iter=3000, C=4))
router.fit(tr.complaint_text, tr["product"])
v2_acc = (router.predict(te.complaint_text) == te["product"]).mean()
# v3: one month of agent corrections. Agents fix the low-confidence routes they handle by hand;
# those 600 corrected complaints (new real-world wording) go back into training.
feedback = make(600, test=True, only_first=True)   # agents only ever saw one of the two new wordings per product
router.fit(pd.concat([tr, feedback]).complaint_text, pd.concat([tr, feedback])["product"])
pred = router.predict(te.complaint_text)
conf = router.predict_proba(te.complaint_text).max(axis=1)
acc = (pred == te["product"]).mean()

flagger = make_pipeline(TfidfVectorizer(ngram_range=(1, 3), min_df=1, sublinear_tf=True),
                        LogisticRegression(max_iter=2000, C=6, class_weight="balanced"))
flagger.fit(pd.concat([tr, feedback]).complaint_text, pd.concat([tr, feedback]).compliance_flag != "")
fprob = flagger.predict_proba(te.complaint_text)[:, 1]
fy = (te.compliance_flag != "").values
fpred = fprob > .35  # low threshold on purpose: missing a compliance complaint is worse than a false alarm

# human-in-the-loop: send low-confidence routes to a person
auto = conf >= .80
auto_acc = (pred[auto] == te["product"].values[auto]).mean()

# time saved: manual triage ~3.5 min each; AI-routed confident ones ~0.5 min check
MANUAL_MIN, CHECK_MIN, MONTHLY = 3.5, 0.5, 9_000
saved_hours = MONTHLY * (auto.mean() * (MANUAL_MIN - CHECK_MIN)) / 60

t0 = time.perf_counter(); router.predict(te.complaint_text[:1000]); ms = (time.perf_counter() - t0)

out = {
    "complaints": len(df), "test_size": len(te), "v1_word_accuracy_pct": round(100 * v1_acc, 1), "v2_typo_tolerant_accuracy_pct": round(100 * v2_acc, 1), "routing_accuracy_pct": round(100 * acc, 1),
    "auto_routed_pct": round(100 * auto.mean(), 1), "auto_routed_accuracy_pct": round(100 * auto_acc, 1),
    "flag_recall_pct": round(100 * recall_score(fy, fpred), 1), "flag_precision_pct": round(100 * precision_score(fy, fpred), 1),
    "flag_rate_pct": round(100 * fy.mean(), 1), "hours_saved_per_month": round(saved_hours),
    "ms_per_1000": round(ms * 1000), "labels": list(PRODUCTS),
    "confusion": confusion_matrix(te["product"], pred, labels=list(PRODUCTS)).tolist(),
    "examples": [],
}
for _, r in te.sample(6, random_state=3).iterrows():
    p = router.predict_proba([r.complaint_text])[0]
    out["examples"].append({"text": r.complaint_text, "routed_to": router.classes_[p.argmax()],
                            "confidence": round(float(p.max()), 2),
                            "compliance_flag": bool(flagger.predict_proba([r.complaint_text])[0, 1] > .35)})
unseen_mask = te.complaint_text.str.lower().apply(lambda s: any(w.lower()[:18] in s for ws in UNSEEN.values() for w in ws))
out["accuracy_seen_wording_pct"] = round(100 * (pred[~unseen_mask.values] == te["product"].values[~unseen_mask.values]).mean(), 1)
out["accuracy_unseen_wording_pct"] = round(100 * (pred[unseen_mask.values] == te["product"].values[unseen_mask.values]).mean(), 1)
(RES / "results.json").write_text(json.dumps(out, indent=2))
print(json.dumps({k: v for k, v in out.items() if k not in ("confusion", "examples", "labels")}, indent=2))
print(classification_report(te["product"], pred, digits=3))
for e in out["examples"][:3]:
    print("-", e)
