# Portfolio Drift & Risk Monitor

**Wealth management · equities · SQL · Python · suitability**

> Tickers and prices are made up (simulated with market, sector and stock-level moves). There's no real client or market data in here, and nothing in this repo is investment advice.

## Why I built this

At a bank's wealth arm, every client gets a model portfolio that matches their risk profile: Conservative 35% stocks, Moderate 60%, Growth 80%. Markets move, and if nobody rebalances, a "Conservative" client slowly ends up holding a growth portfolio. Compliance calls that a **suitability** problem. The client just calls it a bad surprise in a down year.

I wanted to answer the questions a wealth ops or compliance manager would actually ask:

1. How many accounts have drifted away from their model?
2. Is it random, or does it follow how each adviser works?
3. Are any clients sitting on too much of one stock?
4. If we automate drift alerts, what's left over?

## Data

| File | What it is |
|---|---|
| `prices.csv` | daily closes, 28 tickers, Jan 2024 – Dec 2025 |
| `accounts.csv` | 2,500 accounts: risk profile, adviser, rebalancing habit |
| `holdings_open.csv` | what each account bought on day one |
| `models.csv` | target stock % and max volatility per risk profile |

`analyze.py` replays every account through two years of prices. Quarterly accounts get rebalanced every quarter, annual ones once a year, and "never" accounts are left alone. Then it measures each account on the last day.

## What I found

**58% of accounts ($1.09B of $1.75B) are more than 5 points away from their target stock weight.** It's not random. It comes down to the adviser's habit:

| Rebalancing habit | Accounts | Avg drift | Outside ±5 pt band |
|---|---|---|---|
| Never | 971 | 10.6 pts | **93.5%** |
| Annual | 693 | 6.8 pts | 78.4% |
| Quarterly | 836 | 0.7 pts | **0.2%** |

![Drift](results/drift.png)

**62% of Conservative clients now hold more stock than their profile allows.** Stocks beat bonds over the two years, so the equity share crept up on its own.

**One stock created most of the concentration.** QBIT went up about 7x, so it grew to an average of 19% of 524 accounts without anyone buying more. 53% of accounts now have a single stock above 10%. This is the part people miss: **rebalancing doesn't fix it**, because a rebalance tops up the stock sleeve in the same proportions it already has.

**14% of accounts are more volatile than their profile allows** (1-year realized volatility vs. the profile cap). Conservative accounts are the worst at 21%.

## What I'd recommend

| # | Change | Fixes |
|---|---|---|
| 1 | **Automatic drift alert** when an account moves more than 5 pts off target, routed to the adviser with a pre-built rebalance trade | drift, most volatility breaches |
| 2 | **Separate single-stock alert** above 10%, with a conversation script (tax impact, gradual trimming, exchange funds) | concentration, which #1 can't fix |
| 3 | **Adviser scorecard** of exception rates, shared monthly with branch managers | the habit behind the drift |

**Sizing it:** after the drift rule, accounts with *any* exception drop from **71.5% to 53.3%**, and volatility breaches drop from **14.0% to 0.5%**. What's left is almost entirely single-stock concentration, which is why alert #2 has to be its own workflow.

## Requirements sketch

- *As an adviser, I want an alert when a client's stock weight is more than 5 points off target, so I can rebalance before the client's next review.*
  - Alert includes current vs. target weights and a proposed trade list.
  - Taxable accounts show estimated realized gains before the adviser approves.
  - Alerts that stay open more than 10 business days escalate to the branch manager.
- *As a compliance reviewer, I want a monthly list of accounts above their risk profile's volatility cap, so I can confirm the client was contacted.*

## Run it

```bash
pip install pandas numpy matplotlib tabulate
python generate_data.py
python analyze.py
```
