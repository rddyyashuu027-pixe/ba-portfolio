-- Q4. Which advisers carry the most exceptions? (drift OR concentration OR suitability)
SELECT a.adviser_id,
       COUNT(*) AS accounts,
       SUM(ABS(m.equity_weight - mo.target_equity) > 0.05
           OR m.max_single_weight > 0.10
           OR m.volatility > mo.max_volatility)               AS accounts_with_exception,
       ROUND(100.0 * SUM(ABS(m.equity_weight - mo.target_equity) > 0.05
           OR m.max_single_weight > 0.10
           OR m.volatility > mo.max_volatility) / COUNT(*), 1) AS exception_rate_pct
FROM account_metrics m
JOIN accounts a USING (account_id)
JOIN models mo USING (risk_profile)
GROUP BY a.adviser_id
ORDER BY exception_rate_pct DESC, accounts DESC
LIMIT 8;
