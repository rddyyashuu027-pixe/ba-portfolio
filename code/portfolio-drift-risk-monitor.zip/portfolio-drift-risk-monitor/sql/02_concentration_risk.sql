-- Q2. Single-stock concentration: any one name above 10% of the account.
SELECT m.top_ticker, s.sector,
       COUNT(*)                                AS accounts_over_10pct,
       ROUND(AVG(m.max_single_weight) * 100, 1) AS avg_weight_pct,
       ROUND(SUM(m.market_value) / 1e6, 1)     AS aum_affected_musd
FROM account_metrics m
JOIN securities s ON s.ticker = m.top_ticker
WHERE m.max_single_weight > 0.10
GROUP BY m.top_ticker, s.sector
ORDER BY accounts_over_10pct DESC
LIMIT 10;
