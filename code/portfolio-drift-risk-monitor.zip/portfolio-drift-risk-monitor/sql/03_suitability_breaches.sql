-- Q3. Suitability: is realized volatility above what the client's risk profile allows?
SELECT a.risk_profile,
       COUNT(*)                                               AS accounts,
       ROUND(AVG(m.volatility) * 100, 1)                      AS avg_volatility_pct,
       mo.max_volatility * 100                                AS profile_cap_pct,
       SUM(m.volatility > mo.max_volatility)                  AS above_cap,
       ROUND(100.0 * SUM(m.volatility > mo.max_volatility) / COUNT(*), 1) AS above_cap_pct
FROM account_metrics m
JOIN accounts a USING (account_id)
JOIN models mo USING (risk_profile)
GROUP BY a.risk_profile, mo.max_volatility
ORDER BY mo.max_volatility;
