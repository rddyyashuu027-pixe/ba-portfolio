-- Q1. How many accounts have drifted outside the ±5-point equity band, by rebalancing habit?
SELECT a.rebalance_policy,
       COUNT(*)                                                            AS accounts,
       ROUND(AVG(ABS(m.equity_weight - mo.target_equity)) * 100, 1)        AS avg_abs_drift_pts,
       SUM(ABS(m.equity_weight - mo.target_equity) > 0.05)                 AS out_of_band,
       ROUND(100.0 * SUM(ABS(m.equity_weight - mo.target_equity) > 0.05) / COUNT(*), 1) AS out_of_band_pct
FROM account_metrics m
JOIN accounts a USING (account_id)
JOIN models mo USING (risk_profile)
GROUP BY a.rebalance_policy
ORDER BY out_of_band_pct DESC;
