| risk_profile   |   accounts |   avg_volatility_pct |   profile_cap_pct |   above_cap |   above_cap_pct |
|:---------------|-----------:|---------------------:|------------------:|------------:|----------------:|
| Conservative   |        751 |                  9   |                10 |         158 |            21   |
| Moderate       |       1136 |                 12.3 |                14 |         168 |            14.8 |
| Growth         |        613 |                 15   |                18 |          23 |             3.8 |
