| top_ticker   | sector      |   accounts_over_10pct |   avg_weight_pct |   aum_affected_musd |
|:-------------|:------------|----------------------:|-----------------:|--------------------:|
| QBIT         | Technology  |                   524 |             19.1 |               470.9 |
| FORG         | Industrials |                   262 |             15.4 |               190.7 |
| CLDX         | Technology  |                    94 |             19.1 |                51.3 |
| RAIL         | Industrials |                    55 |             16.2 |                37.4 |
| SYNQ         | Technology  |                    51 |             15   |                47.6 |
| AERO         | Industrials |                    43 |             15.4 |                37.6 |
| MEDI         | Healthcare  |                    38 |             14.9 |                27.7 |
| RIDE         | Consumer    |                    35 |             17.7 |                21.8 |
| PIXL         | Technology  |                    32 |             16.9 |                15.8 |
| NOVA         | Technology  |                    21 |             19.1 |                13.6 |
