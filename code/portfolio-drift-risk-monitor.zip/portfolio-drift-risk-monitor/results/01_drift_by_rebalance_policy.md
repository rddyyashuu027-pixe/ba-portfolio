| rebalance_policy   |   accounts |   avg_abs_drift_pts |   out_of_band |   out_of_band_pct |
|:-------------------|-----------:|--------------------:|--------------:|------------------:|
| Never              |        971 |                10.6 |           908 |              93.5 |
| Annual             |        693 |                 6.8 |           543 |              78.4 |
| Quarterly          |        836 |                 0.7 |             2 |               0.2 |
