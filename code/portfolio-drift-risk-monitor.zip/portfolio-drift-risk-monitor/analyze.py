"""Portfolio drift & risk monitor.

1. Replays each account from Jan 2024 to Dec 2025 under its adviser's rebalancing habit.
2. Builds one row per account (equity weight, biggest position, 1-year volatility).
3. Runs the SQL in sql/ and sizes an automatic drift-alert rule.

    python generate_data.py && python analyze.py
"""
import json
import sqlite3
from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = Path(__file__).parent
D, RES = ROOT / "data", ROOT / "results"
RES.mkdir(exist_ok=True)
BAND = 0.05

px = pd.read_csv(D / "prices.csv").pivot(index="date", columns="ticker", values="close")
sec = pd.read_csv(D / "securities.csv")
accts = pd.read_csv(D / "accounts.csv")
models = pd.read_csv(D / "models.csv")
hold = pd.read_csv(D / "holdings_open.csv")
bench = pd.read_csv(D / "benchmark.csv").set_index("date").benchmark
is_eq = sec.set_index("ticker").asset_class.eq("Equity")
target = accts.merge(models, on="risk_profile").set_index("account_id").target_equity

dates = px.index
quarter_ends = set(pd.Series(dates).groupby(pd.to_datetime(pd.Series(dates)).dt.to_period("Q")).max())
year_ends = {"2024-12-31"} & set(dates)
asof = dates[-1]


def replay(shares, policy, tgt):
    """Rebalance equity/bond sleeves back to target on the policy's schedule, keep picks within sleeves."""
    s = shares.copy()
    open_w = (s * px.iloc[0][s.index]); open_w = open_w / open_w.sum()
    eq_mask = is_eq[s.index].values
    sleeve = np.where(eq_mask, open_w / open_w[eq_mask].sum(), open_w / open_w[~eq_mask].sum())
    sched = quarter_ends if policy == "Quarterly" else year_ends if policy == "Annual" else set()
    for d in sorted(sched):
        if d == asof:
            continue
        p = px.loc[d, s.index]
        val = (s * p).sum()
        w = np.where(eq_mask, tgt * sleeve, (1 - tgt) * sleeve)
        s = pd.Series(val * w / p.values, index=s.index)
    return s


rows, book = [], None
for acct, g in hold.groupby("account_id"):
    a = accts.set_index("account_id").loc[acct]
    s = replay(g.set_index("ticker").shares, a.rebalance_policy, target[acct])
    mv = s * px.loc[asof, s.index]
    w = mv / mv.sum()
    rets = px[s.index].iloc[-253:].pct_change().dropna() @ w.values
    we = w[is_eq[w.index].values]  # single-name risk only applies to stocks, bond funds are diversified
    rows.append((acct, mv.sum(), we.sum(), we.max(), we.idxmax(), rets.std() * np.sqrt(252)))
    series = (px[s.index] * s).sum(axis=1)  # approx: post-rebalance shares applied to the whole path
    book = series if book is None else book + series
m = pd.DataFrame(rows, columns=["account_id", "market_value", "equity_weight", "max_single_weight",
                                "top_ticker", "volatility"])

con = sqlite3.connect(":memory:")
for name, df in (("account_metrics", m), ("accounts", accts), ("models", models), ("securities", sec)):
    df.to_sql(name, con, index=False)
res = {}
for f in sorted((ROOT / "sql").glob("*.sql")):
    df = pd.read_sql(f.read_text(), con)
    res[f.stem] = df.to_dict("records")
    (RES / f"{f.stem}.md").write_text(df.to_markdown(index=False) + "\n")
    print(f"\n## {f.stem}\n" + df.to_markdown(index=False))

mm = m.merge(accts, on="account_id").merge(models, on="risk_profile")
mm["drift"] = mm.equity_weight - mm.target_equity
mm["out_band"] = mm.drift.abs() > BAND
mm["concentrated"] = mm.max_single_weight > 0.10
mm["too_risky"] = mm.volatility > mm.max_volatility
mm["any_exception"] = mm.out_band | mm.concentrated | mm.too_risky

# Rule: alert + rebalance any account outside the band. Drift and most vol breaches go away;
# concentration does not, because rebalancing keeps the same names inside the equity sleeve.
after = mm.copy()
after.loc[after.out_band, "too_risky"] = after.loc[after.out_band].apply(
    lambda r: r.volatility * (r.target_equity / max(r.equity_weight, .01)) > r.max_volatility, axis=1)
after["out_band"] = False
after["any_exception"] = after.out_band | after.concentrated | after.too_risky

summary = {
    "accounts": len(mm), "aum_musd": round(mm.market_value.sum() / 1e6, 1),
    "out_of_band_pct": round(100 * mm.out_band.mean(), 1),
    "concentrated_pct": round(100 * mm.concentrated.mean(), 1),
    "too_risky_pct": round(100 * mm.too_risky.mean(), 1),
    "any_exception_pct": round(100 * mm.any_exception.mean(), 1),
    "aum_out_of_band_musd": round(mm.loc[mm.out_band, "market_value"].sum() / 1e6, 1),
    "after_rule_any_exception_pct": round(100 * after.any_exception.mean(), 1),
    "after_rule_too_risky_pct": round(100 * after.too_risky.mean(), 1),
    "conservative_overweight_equity_pct": round(100 * ((mm.risk_profile == "Conservative") & (mm.drift > BAND)).sum()
                                             / (mm.risk_profile == "Conservative").sum(), 1),
}
print("\n## summary\n" + json.dumps(summary, indent=2))
res["summary"] = summary
res["drift_points"] = (mm.drift * 100).round(1).tolist()
# per account: [drift pts, too risky today, too risky if rebalanced to target] for the portfolio slider
if_rebal = mm.volatility * (mm.target_equity / mm.equity_weight.clip(lower=.01)) > mm.max_volatility
res["risk_flags"] = [[round(d * 100, 1), int(n), int(r)] for d, n, r in zip(mm.drift, mm.too_risky, if_rebal)]
wk = book.iloc[::5]
res["book_vs_benchmark"] = {"dates": list(wk.index), "book": (100 * wk / wk.iloc[0]).round(2).tolist(),
                            "benchmark": (100 * bench[wk.index] / bench.iloc[0]).round(2).tolist()}
mv_all = hold.merge(sec, on="ticker")
mv_all["mv"] = mv_all.shares * mv_all.ticker.map(px.loc[asof])
res["sector_mix"] = (mv_all.groupby("sector").mv.sum() / mv_all.mv.sum() * 100).round(1).sort_values(ascending=False).to_dict()
(RES / "results.json").write_text(json.dumps(res, indent=2, default=float))

# charts
blue, light, red, grey = "#1f6feb", "#58a6ff", "#e5534b", "#8b949e"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(figsize=(8, 3.6))
for prof, col in (("Conservative", light), ("Moderate", blue), ("Growth", grey)):
    ax.hist(mm.loc[mm.risk_profile == prof, "drift"] * 100, bins=40, alpha=.65, label=prof, color=col)
ax.axvspan(-5, 5, color=blue, alpha=.08)
ax.axvline(-5, color=red, ls=":"); ax.axvline(5, color=red, ls=":")
ax.set_xlabel("equity weight minus target, percentage points"); ax.set_ylabel("accounts")
ax.set_title("Equity drift vs. model (shaded = ±5 pt policy band)"); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig(RES / "drift.png", dpi=150)

pol = pd.DataFrame(res["01_drift_by_rebalance_policy"])
fig, ax = plt.subplots(figsize=(6, 3.4))
ax.bar(pol.rebalance_policy, pol.out_of_band_pct, color=[red if p == "Never" else blue for p in pol.rebalance_policy])
for i, v in enumerate(pol.out_of_band_pct):
    ax.text(i, v + 1, f"{v}%", ha="center", fontweight="bold")
ax.set_ylabel("% accounts outside band"); ax.set_title("Drift follows the adviser's rebalancing habit")
fig.tight_layout(); fig.savefig(RES / "by_policy.png", dpi=150)
