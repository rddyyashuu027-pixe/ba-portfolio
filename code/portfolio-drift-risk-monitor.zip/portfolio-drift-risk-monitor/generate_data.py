"""Synthetic wealth-management book: prices, client accounts, holdings, model portfolios.

Tickers are fictional. Prices are simulated with a market factor + sector factor +
stock noise, so sectors move together the way real equities do. No real market or
client data. Run:  python generate_data.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

rng = np.random.default_rng(21)
OUT = Path(__file__).parent / "data"
OUT.mkdir(exist_ok=True)

SECTORS = {  # sector: (annual drift, sector vol, tickers)
    "Technology": (0.20, 0.22, ["NOVA", "QBIT", "CLDX", "SYNQ", "PIXL"]),
    "Financials": (0.09, 0.16, ["HARB", "LEDG", "MRCH", "VLTB"]),
    "Healthcare": (0.07, 0.13, ["GENX", "MEDI", "CURA", "VITL"]),
    "Energy": (0.03, 0.24, ["PTRL", "WATT", "SOLR"]),
    "Consumer": (0.08, 0.14, ["CART", "BRWS", "DINE", "RIDE"]),
    "Industrials": (0.10, 0.15, ["FORG", "RAIL", "AERO"]),
    "Utilities": (0.05, 0.10, ["GRID", "HYDR"]),
    "Fixed Income": (0.035, 0.05, ["BNDA", "TRSY", "CORP"]),
}
DAYS = pd.bdate_range("2024-01-02", "2025-12-31")
n = len(DAYS)
mkt = rng.normal(0.10 / 252, 0.14 / np.sqrt(252), n)

rows, meta = [], []
for sector, (mu, vol, tickers) in SECTORS.items():
    sec = rng.normal(0, vol / np.sqrt(252), n)
    beta = 0.15 if sector == "Fixed Income" else 1.0
    for t in tickers:
        idio = rng.normal(0, (0.03 if sector == "Fixed Income" else 0.20) / np.sqrt(252), n)
        r = beta * mkt + sec + idio + (mu - beta * 0.10) / 252
        price = 100 * np.exp(np.cumsum(r)) * rng.uniform(.4, 3)
        rows.append(pd.DataFrame({"date": DAYS.strftime("%Y-%m-%d"), "ticker": t, "close": price.round(2)}))
        meta.append((t, sector, "Bond" if sector == "Fixed Income" else "Equity"))
pd.concat(rows).to_csv(OUT / "prices.csv", index=False)
sec_df = pd.DataFrame(meta, columns=["ticker", "sector", "asset_class"])
sec_df.to_csv(OUT / "securities.csv", index=False)
pd.DataFrame({"date": DAYS.strftime("%Y-%m-%d"),
              "benchmark": (100 * np.exp(np.cumsum(mkt))).round(2)}).to_csv(OUT / "benchmark.csv", index=False)

# Model portfolios and client accounts
models = pd.DataFrame([("Conservative", 0.35, 0.10), ("Moderate", 0.60, 0.14), ("Growth", 0.80, 0.18)],
                      columns=["risk_profile", "target_equity", "max_volatility"])
models.to_csv(OUT / "models.csv", index=False)

eq = sec_df[sec_df.asset_class == "Equity"].ticker.values
bd = sec_df[sec_df.asset_class == "Bond"].ticker.values
start_px = pd.read_csv(OUT / "prices.csv").query("date == '2024-01-02'").set_index("ticker").close

accts, holds = [], []
for i in range(2500):
    prof = rng.choice(models.risk_profile, p=[.3, .45, .25])
    tgt = models.set_index("risk_profile").loc[prof, "target_equity"]
    value = float(np.exp(rng.normal(np.log(350_000), .9)))
    # last rebalance: some advisors rebalance quarterly, many never after onboarding
    rebal = rng.choice(["Quarterly", "Annual", "Never"], p=[.35, .25, .40])
    adviser = f"ADV{rng.integers(1, 41):02d}"
    accts.append((f"AC{i:05d}", prof, rebal, adviser, round(value, 2)))
    picks = rng.choice(eq, size=rng.integers(12, 19), replace=False)
    w = rng.dirichlet(np.ones(len(picks)) * 6) * tgt
    if rng.random() < 0.11:  # concentrated position: employer stock or a favourite name
        big = rng.uniform(.13, .28)
        w = np.concatenate([[big], w[1:] / w[1:].sum() * (tgt - big)])
    bw = rng.dirichlet(np.ones(len(bd))) * (1 - w.sum())
    for t, wt in list(zip(picks, w)) + list(zip(bd, bw)):
        holds.append((f"AC{i:05d}", t, round(value * wt / start_px[t], 4)))
pd.DataFrame(accts, columns=["account_id", "risk_profile", "rebalance_policy", "adviser_id",
                             "opening_value"]).to_csv(OUT / "accounts.csv", index=False)
pd.DataFrame(holds, columns=["account_id", "ticker", "shares"]).to_csv(OUT / "holdings_open.csv", index=False)
print(f"{len(DAYS)} trading days, {len(sec_df)} tickers, {len(accts)} accounts, {len(holds)} positions -> {OUT}")
