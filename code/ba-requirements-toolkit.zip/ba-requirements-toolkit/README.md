# BA Requirements Toolkit: ACH First-Debit Validation

**The documents a business analyst produces around one change, end to end.**

This repo is the requirements side of the [ACH Return Rate Reduction](https://github.com/rddyyashuu027-pixe/ach-return-rate-reduction) case study. The analysis found *what* to change. These artifacts show *how* the change gets specified, built, tested, and measured.

| Artifact | File | Purpose |
|---|---|---|
| Business Requirements Document | [`BRD.md`](BRD.md) | scope, business rules, non-functional needs, sign-off |
| Process maps (current & future) | [`process-maps.md`](process-maps.md) | where the return happens today and where the new control sits |
| Requirements Traceability Matrix | [`RTM.csv`](RTM.csv) | every requirement → user story → test case → KPI |
| UAT test cases | [`UAT_test_cases.csv`](UAT_test_cases.csv) | given / when / then, with expected results |
| KPI data dictionary | [`KPI_dictionary.md`](KPI_dictionary.md) | one definition per metric, so every team counts the same way |
