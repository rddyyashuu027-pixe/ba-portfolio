# KPI data dictionary

| KPI | Definition | Numerator | Denominator | Grain | Target | Source |
|---|---|---|---|---|---|---|
| Overall ACH return rate | share of originated debits returned for any reason | debits with any return code | all originated debits | month | ≤ 2.40% | `ach_entries` |
| Admin return rate, first debits | preventable account-level returns on first debits | first debits returned R02/R03/R04 | all first debits | month | < 1.0% | `ach_entries` |
| Unauthorized return rate | NACHA unauthorized ratio | returns R05/R07/R10/R11/R29 | all debits | month | < 0.5% (NACHA) | `ach_entries` |
| Validation hold rate | share of first debits held by the rule | first debits held | first debits validated | day | monitor | validation log |
| Hold-to-completion rate | held customers who fix their account | held accounts later validated | held accounts | week | ≥ 70% | validation log |

**Rules:** a return is counted in the month of the **original entry's effective date**, not the return date, so late returns don't move between months. Test entries and reversals are excluded.
