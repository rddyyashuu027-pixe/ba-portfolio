# Business Requirements Document: First-Debit Account Validation

| | |
|---|---|
| **Version** | 1.0 |
| **Business owner** | Payments Operations |
| **Status** | Draft for review |

## 1. Background
Administrative ACH returns (R02/R03/R04) are 20.9% of all returns. They cluster on **first debits to accounts that were never validated**, which return at 8.2% vs 2.9% for validated first debits. See the [analysis](https://github.com/rddyyashuu027-pixe/ach-return-rate-reduction).

## 2. Objective
Lower the overall ACH return rate from **2.69% to ≤ 2.40%** within one quarter of launch, without adding friction for existing payers.

## 3. Scope
**In:** first ACH debit on any newly enrolled external account, all origination channels.
**Out:** repeat debits; credits; wire and card payments; changes to NSF (R01) handling.

## 4. Business rules
| ID | Rule |
|---|---|
| BR-01 | A first debit is the first ACH debit originated to an account + routing number pair. |
| BR-02 | Every first debit must have a `valid` real-time account validation response, or a successful prenote, before origination. |
| BR-03 | `invalid`, `closed`, or `not found` responses hold the debit and notify the customer within 1 business day. |
| BR-04 | If the validation service times out, the debit is **held**, not originated (fail-closed). Agreed with Risk. |
| BR-05 | Repeat debits are never re-validated by this rule. |
| BR-06 | Every validation call and hold is logged with timestamp, response, and reason for audit. |

## 5. Functional requirements
| ID | Requirement | Priority |
|---|---|---|
| FR-01 | Identify first debits in the daily origination file | Must |
| FR-02 | Call the account validation service for each first debit | Must |
| FR-03 | Hold and route failed validations to a "customer action" queue | Must |
| FR-04 | Send the customer an "update your bank account" message (email + in-app) | Must |
| FR-05 | Daily report of holds by channel and response | Should |
| FR-06 | Allow ops to release a held debit with a reason code | Should |

## 6. Non-functional requirements
- Validation adds ≤ 2 seconds per enrollment in web/mobile.
- File processing completes before the existing ACH cutoff.
- Audit logs kept for 7 years.

## 7. Success measures
See [`KPI_dictionary.md`](KPI_dictionary.md): admin return rate on first debits < 1.0%, overall return rate ≤ 2.40%, hold-to-completion rate ≥ 70%.

## 8. Risks & assumptions
| Risk | Mitigation |
|---|---|
| Customers abandon after a hold | clear message + one-tap account update; track completion rate |
| Vendor fee higher than modeled | break-even is $3.85 per return; renegotiate above that |
| Fail-closed delays legitimate payments | monitor timeout rate; review the BR-04 decision at 30 days |

## 9. Sign-off
| Role | Name | Date |
|---|---|---|
| Payments Operations | | |
| Digital Channels | | |
| Risk & Compliance | | |
| Technology | | |
