# Process maps

## Current state: the error is found two days later

```mermaid
flowchart LR
  A[Customer enrolls account<br/>web / mobile] --> B[Account saved<br/>no validation]
  B --> C[First debit in<br/>origination file]
  C --> D[ACH network]
  D --> E{Receiving bank}
  E -- valid --> F[Settled ✅]
  E -- R02 / R03 / R04 --> G[Return received T+2 ❌]
  G --> H[Ops works return<br/>contacts customer]
  H --> A
```

## Future state: the error is caught at enrollment

```mermaid
flowchart LR
  A[Customer enrolls account] --> V{Real-time<br/>account validation}
  V -- valid --> C[First debit originated]
  V -- invalid / closed --> X[Hold + ask customer<br/>to update account]
  X --> A
  V -- timeout --> X
  C --> D[ACH network] --> F[Settled ✅]
```

**What changed:** the control moves from *after* the money moves (a return) to *before* it moves (a validation). Repeat debits skip the new step.
