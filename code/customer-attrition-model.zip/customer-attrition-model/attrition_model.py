"""Deposit customer attrition: who is about to leave, and who is worth a retention offer?

Synthetic data (40K customers). Compares a simple scorecard (logistic regression) with
gradient boosting, then turns the score into a business decision: how many customers to
call, given an offer cost and what a saved customer is worth.

    python attrition_model.py
"""
import json
from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

RES = Path(__file__).parent / "results"
RES.mkdir(exist_ok=True)
rng = np.random.default_rng(8)
N = 40_000

# ---------- synthetic customers ----------
df = pd.DataFrame({
    "tenure_months": rng.gamma(2.2, 26, N).clip(1, 360).round(),
    "products_held": rng.choice([1, 2, 3, 4], N, p=[.38, .34, .2, .08]),
    "avg_balance_k": np.exp(rng.normal(2.2, 1.1, N)).round(1),
    "balance_change_90d_pct": rng.normal(-2, 18, N).round(1),
    "direct_deposit": rng.random(N) < .55,
    "digital_logins_30d": rng.poisson(9, N),
    "logins_change_pct": rng.normal(0, 30, N).round(1),
    "fee_events_90d": rng.poisson(.6, N),
    "complaints_12m": rng.poisson(.15, N),
    "age": rng.integers(19, 85, N),
})
logit = (-0.55 - 0.012 * df.tenure_months - 0.45 * (df.products_held - 1) - 0.9 * df.direct_deposit
         - 0.035 * df.balance_change_90d_pct - 0.012 * df.logins_change_pct + 0.35 * df.fee_events_90d
         + 0.75 * df.complaints_12m - 0.05 * df.digital_logins_30d
         + 0.9 * ((df.balance_change_90d_pct < -25) & (df.direct_deposit == 0)))  # interaction: money moving out
df["churned_12m"] = rng.random(N) < 1 / (1 + np.exp(-logit))
X, y = df.drop(columns="churned_12m").astype(float), df.churned_12m
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.3, random_state=0, stratify=y)

# ---------- models ----------
models = {
    "Logistic scorecard": make_pipeline(StandardScaler(), LogisticRegression(max_iter=500)),
    "Gradient boosting": HistGradientBoostingClassifier(max_iter=300, learning_rate=.05, random_state=0),
}
scores, auc = {}, {}
for name, m in models.items():
    m.fit(Xtr, ytr)
    scores[name] = m.predict_proba(Xte)[:, 1]
    auc[name] = round(roc_auc_score(yte, scores[name]), 3)
best = max(auc, key=auc.get)
p = scores[best]

# lift by decile
order = np.argsort(-p)
yt = yte.values[order]
deciles = np.array_split(yt, 10)
base = yte.mean()
lift = [{"decile": i + 1, "churn_rate_pct": round(100 * d.mean(), 1), "lift": round(d.mean() / base, 2),
         "cum_capture_pct": round(100 * np.concatenate(deciles[:i + 1]).sum() / yt.sum(), 1)} for i, d in enumerate(deciles)]

# ---------- decision: how many to call ----------
CUSTOMER_VALUE = 420     # 12-month net revenue of a retained customer, USD (assumption)
OFFER_COST = 25          # retention offer + agent time per contacted customer, USD
SAVE_RATE = 0.25         # share of would-be churners an offer actually keeps
n = len(yt)
curve = []
for k in range(1, 101):
    top = yt[: int(n * k / 100)]
    profit = top.sum() * SAVE_RATE * CUSTOMER_VALUE - len(top) * OFFER_COST
    curve.append({"pct_contacted": k, "net_value": round(float(profit) * (N / n)), "churners_caught_pct": round(100 * top.sum() / yt.sum(), 1)})
best_k = max(curve, key=lambda c: c["net_value"])

# drivers (logistic coefficients on standardized features = direction + relative strength)
coef = models["Logistic scorecard"][-1].coef_[0]
drivers = sorted(zip(X.columns, coef.round(3)), key=lambda t: -abs(t[1]))[:7]

out = {"customers": N, "churn_rate_pct": round(100 * y.mean(), 1), "auc": auc, "best_model": best,
       "lift": lift, "decision_curve": curve, "best_contact": best_k,
       "drivers": [{"feature": f, "weight": float(w)} for f, w in drivers],
       "assumptions": {"customer_value": CUSTOMER_VALUE, "offer_cost": OFFER_COST, "save_rate": SAVE_RATE}}
(RES / "results.json").write_text(json.dumps(out, indent=2))
print(json.dumps({k: out[k] for k in ("churn_rate_pct", "auc", "best_model", "best_contact")}, indent=2))
print(pd.DataFrame(lift).to_markdown(index=False))
print(pd.DataFrame(out["drivers"]).to_markdown(index=False))

# ---------- charts ----------
blue, grey = "#3b82f6", "#9aa4b2"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.bar([d["decile"] for d in lift], [d["churn_rate_pct"] for d in lift], color=[blue] * 2 + [grey] * 8)
ax.axhline(100 * base, color="#e5534b", ls=":"); ax.text(9.6, 100 * base + .5, "average", color="#e5534b", ha="right")
ax.set_xlabel("risk decile (1 = highest score)"); ax.set_ylabel("actual churn %")
ax.set_title(f"{best}: top 2 deciles hold {lift[1]['cum_capture_pct']}% of churners")
fig.tight_layout(); fig.savefig(RES / "lift.png", dpi=150)

fig, ax = plt.subplots(figsize=(7, 3.6))
ax.plot([c["pct_contacted"] for c in curve], [c["net_value"] / 1e3 for c in curve], color=blue, lw=2.5)
ax.axvline(best_k["pct_contacted"], color=grey, ls="--")
ax.text(best_k["pct_contacted"] + 1, best_k["net_value"] / 1e3, f"call top {best_k['pct_contacted']}%\n${best_k['net_value']/1e3:.0f}K / yr")
ax.axhline(0, color="#e5534b", lw=.8)
ax.set_xlabel("% of customers contacted (highest risk first)"); ax.set_ylabel("net value, $K")
ax.set_title("Calling everyone loses money. Calling the right few doesn't.")
fig.tight_layout(); fig.savefig(RES / "decision_curve.png", dpi=150)
