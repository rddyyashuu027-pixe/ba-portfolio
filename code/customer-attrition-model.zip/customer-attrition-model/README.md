# Customer Attrition Model: Who's About to Leave, and Who's Worth a Call?

**Machine learning for a business decision · Python · scikit-learn · logistic regression vs. gradient boosting**

> 40K synthetic deposit customers. No real bank data.

## The question I was answering

The retention team has a budget for offers (a fee waiver, a rate bump) and a few agents to make calls. Last year they called whoever's balance dropped. The questions were:

1. Can we predict who will close their account in the next 12 months?
2. If we can, **how many** people should we call? Calling costs money too.

## What I built

- Two models trained on the same features: a **logistic regression scorecard** and **gradient boosting**.
- A **lift table** showing how much better than random the top-scored customers are.
- A **decision curve** that turns the model into dollars: value of customers saved minus cost of calls, for every possible call-list size.

## Results

| Model | AUC (held-out 30%) |
|---|---|
| **Logistic scorecard** | **0.785** |
| Gradient boosting | 0.777 |

**I'd ship the simpler one.** It scores slightly better here. Just as important, a risk or model-validation team can read every coefficient, and banks have to explain models they use with customers.

![Lift](results/lift.png)

| Risk decile | Actual attrition | Lift | Churners caught so far |
|---|---|---|---|
| 1 (highest) | 50.2% | 3.4x | 34% |
| 2 | 26.7% | 1.8x | 53% |
| 3 | 20.0% | 1.4x | 66% |
| 10 (lowest) | 2.2% | 0.15x | 100% |

**What drives attrition** (standardized logistic weights): money leaving the account over the last 90 days is the strongest signal. After that come no direct deposit, short tenure, fewer products, and a drop in app logins. Fees and complaints push risk up.

## The decision

![Decision curve](results/decision_curve.png)

Assumptions (in the script, easy to change): a saved customer is worth **$420/yr**, an offer plus agent time costs **$25**, and an offer keeps **25%** of the people who would have left.

| Who we call | Churners reached | Net value / yr |
|---|---|---|
| **Top 17% by score** | **48%** | **+$125K** |
| Top 50% | 83% | +$7K |
| Everyone | 100% | **−$386K** |

**Calling more people isn't better.** Past the top ~17%, each extra call costs more than it saves. My recommendation is a weekly call list of the top 17%, with the cutoff re-checked each quarter against actual saves.

## What I'd check before using it for real

- Fairness: make sure no protected-class proxies are driving scores (age is in the data on purpose, so it can be tested and removed).
- Run a holdout group that gets no calls, so the 25% save rate gets measured instead of assumed.
- Monitor the score distribution monthly (drift).

## Run it

```bash
pip install pandas numpy scikit-learn matplotlib tabulate
python attrition_model.py
```
